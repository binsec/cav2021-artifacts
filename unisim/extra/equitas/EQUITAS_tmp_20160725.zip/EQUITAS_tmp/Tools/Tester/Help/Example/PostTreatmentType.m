function [Err] = PostTreatmentType(ModelRef,ResultFile,TestData)
%% PostTreatmentType function type
% Do not modify the prototype (Inputs & outputs arguments) of this function 
% otherwise, it will not work properly with PhiTests
%
% Inputs:
%   ModelRef: Name of the model (Without extension mdl or slx) (char)
%   ResultFile: Name of the result file if any specified (char)
%   TestData: Structure which defines this test
%       Ref: Name of the test in progress (char)
%       Pre: Pre-scenario (char)
%       Sce: Scenario (char)
%       Post: Post-scenario (char)
%       Calib: Calibration file (m or mat file) (char)
%       PostTreatment: Function for post treatment to perform (char, field not mandatory)
%
% Outputs:
%   Err: Contains errors & warnings occurred during post treatment. Use the
%        Class Err_Class to be compatible with the Tester. If no error
%        management, initialize Err to empty data []
%

%% Init
% Output Err must return Err_Class or empty data
Err = Err_Class(); % To add an error, use "Set_Err" method


%% Develop your own post treatment function
% Take care, to get or set workspace data, you should use "evalin" or
% "assignin" functions (Cf. Matlab help)
%

disp('Specify your own code here')


end


