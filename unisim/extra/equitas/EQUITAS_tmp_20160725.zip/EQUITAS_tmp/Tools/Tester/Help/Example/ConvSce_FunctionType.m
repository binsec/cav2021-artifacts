% ======================== ConvSce_FunctionType ========================
%
% This function is the prototype to convert a scenario into format
% compatible with the Tester
% This function has 2 differents ways of working:
%   - Converts the file into scenario compatible with the Tester
%   - Returns a structure with information on this function
%
% To develop your own conversion function, the developer must modified this
% prototype by following this rules:
%   - Change the name of the function
%   - Save this function into the directory ~\ScenarioMgt
%   - If needed, create a folder with the function name to add your owns functions
%   - Do not modify this prototype, except between the 2 following Tags
%           %==> Begin your own code #########################################################################
%
%           %==> End of your own code ########################################################################
%
% Inputs:
%   File: Path & Name of the file to convert
%   varargin: input arguments not mandatory
%        - {1} ConfFile: Excel file which configure the Tester
%
% Outputs:
%   varargout: Returns :
%     - Case 1 Structure with function information if no File is specified
%     - Case 2 if File is specified
%           Scenario
%           Err
%
% Exemple:
%   Sce = ConvSce_FunctionType(File);
%   [Sce,Err] = ConvSce_FunctionType(File);
%   [Sce,Err] = ConvSce_FunctionType(File,ConfFile);
%   Fct_Info = ConvSce_FunctionType();
%
% Versions :
% 0.1 -- 15/10/15 -- Y.FREMY (Sherpa Engineering) -- Creation of the prototype
%
%

function varargout = ConvSce_FunctionType(File,varargin)


%% Description of this function
%==> Begin your own code #########################################################################
% Update information for your own conversion's function
Fct_Info.Name = mfilename;
Fct_Info.ScenarioExt = [{'.txt'};{'.m'}]; % Extension file allowed for scenarii
Fct_Info.Label = 'Name of this conversion'; % Name used by HMI to select this method
Fct_Info.Description = {'';...
    'Description for this conversion';...
    ''}; % Description of this function
Fct_Info.History.Version = '0.0.1';
Fct_Info.History.Date = '2015/10/08 18h37';
Fct_Info.History.Author = 'Yann FREMY';
Fct_Info.History.Description = 'Add function description management';
%==> End of your own code ########################################################################


%% Inputs managements
if nargin == 0
    %% Return the function description
    varargout{1} = Fct_Info;
    return;
end


%% Init
Sce = Scenario_Element;
Err = Err_Class();

%% Add local path
Status = AddLocalPath(which(mfilename));
if ~Status
    %% Error
    Err.Set_Err(500,'Error',['Impossible to add the folder "',mfilename,'". Conversion cancelled.'],mfilename);
else
    % Check if the file exist
    if exist(File) ~= 2
        Err.Set_Err(501,'Error',...
            ['Cannot open the input file: ',File],...
            mfilename);
    else
        % Check extension compatibility
        [PathFile,NameFile,ext] = fileparts(File);
        ExtCompatible = false;
        ExtExpected = '{';
        for i_ext = 1:length(Fct_Info.ScenarioExt)
            if strcmpi(Fct_Info.ScenarioExt{i_ext},ext) == 1
                ExtCompatible = true;
            end
            ExtExpected = [ExtExpected,Fct_Info.ScenarioExt{i_ext},' '];
        end
        ExtExpected = [ExtExpected,'}'];
        
        if ~ExtCompatible
            Err.Set_Err(502,'Error',...
                ['Incorrect extension file : "',ext,'" instead of: ',ExtExpected],...
                mfilename);
        else
            %% Conversion phase
            %==> Begin your own code #########################################################################
            % Develop your own conversion's function by using the methods of the Class "Scenario_Element"
            % Refer to the help file: "Syntaxe Scenario Sequenceur.pdf"
            
            
            
            
            
            
            
            
            
            
            
            %==> End of your own code ########################################################################
            
            % Update the scenario
            Sce.Import_Includes;
            Sce.Update_Index;
        end
    end
end


%% Returns data
% Scenario
varargout{1} = Sce;

% Error
Err.Concatenate_Err(Sce.Err);
if nargout >= 2
    % Returns Errors
    varargout{2} = Err;
elseif nargout <= 1
    % Disp Errors
    Err.Disp_Err();
end

end

