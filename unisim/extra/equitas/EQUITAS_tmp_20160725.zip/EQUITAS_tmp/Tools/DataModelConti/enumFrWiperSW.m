classdef enumFrWiperSW <  Simulink.IntEnumType
    enumeration 
        OFF (0)
        INT (1)
        LO (2)
        HI (3)
    end
end

