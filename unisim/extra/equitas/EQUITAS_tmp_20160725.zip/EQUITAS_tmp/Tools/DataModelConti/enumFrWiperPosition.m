classdef enumFrWiperPosition < Simulink.IntEnumType
    enumeration 
        NOT_STOP (0);
        STOP (1);
    end
end

