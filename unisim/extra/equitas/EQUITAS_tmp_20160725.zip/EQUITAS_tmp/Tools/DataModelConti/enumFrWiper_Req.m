classdef enumFrWiper_Req < Simulink.IntEnumType
    enumeration 
        NO_REQ (0);
        SW_LO (1);
        SW_HI (2);
        SW_INT (3)
        RAIN_LO (4);
        RAIN_HI (5);
    end
end

