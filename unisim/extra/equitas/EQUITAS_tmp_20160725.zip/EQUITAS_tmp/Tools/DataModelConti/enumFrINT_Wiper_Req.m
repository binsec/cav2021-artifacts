classdef enumFrINT_Wiper_Req < Simulink.IntEnumType
    enumeration 
        INT_NO_REQ (0);
        INT_LO (1)
        INT_RAIN_LO (2);
        INT_RAIN_HI (3);
    end
end
