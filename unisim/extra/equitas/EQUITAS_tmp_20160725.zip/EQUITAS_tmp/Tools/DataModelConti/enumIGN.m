classdef enumIGN < Simulink.IntEnumType
    enumeration 
        OFF (0);
        IGN (1);
    end
end

