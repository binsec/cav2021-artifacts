classdef enumAUTO_LIGHT < Simulink.IntEnumType
    enumeration
        WITHOUT (0);
        RAIN_AND_LIGHT_SENSOR (1);
        JPN_WO_ENHANCED_AUTOLIGHT (2);
        JPN_W_ENHANCED_AUTOLIGHT (3);
        NAM_WO_ENHANCED_AUTOLIGHT (4);
        NAM_W_ENHANCED_AUTOLIGHT (5);
    end
end

