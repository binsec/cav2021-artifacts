classdef enumFrWiperOut < Simulink.IntEnumType
    enumeration 
        OUT_STOP (0);
        OUT_FORCED_TO_STOP (1);
        OUT_ONE_LOW_SPEED (2);
        OUT_LOW_SPEED (3);
        OUT_HIGH_SPEED (4);
        OUT_ERROR (5);
    end
end

