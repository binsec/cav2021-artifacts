classdef enumRainSensor_ECU_FrWiper_Req <  Simulink.IntEnumType
    enumeration 
        RS_ERROR (-1)
        RS_NO_REQ (0)
        RS_RAIN_LO (1)
        RS_RAIN_HI (2)
    end
end