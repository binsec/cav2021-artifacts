classdef enumFrWiperRiseUp_Req < Simulink.IntEnumType
    enumeration 
        RISEUP_NO_REQ (0);
        RISEUP_REQ (1);
        RISEUP_FORCED_TO_STOP (2);
    end
end
