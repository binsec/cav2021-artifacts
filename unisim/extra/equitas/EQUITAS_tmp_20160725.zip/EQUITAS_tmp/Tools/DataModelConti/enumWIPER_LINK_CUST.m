classdef enumWIPER_LINK_CUST < Simulink.IntEnumType
    enumeration
        WLC_WITHOUT (0);
        WLC_LOW_AND_HI (1);
        WLC_INT_LOW_AND_HI (2);
    end
end

