classdef enumFrWasherWiper_Req < Simulink.IntEnumType
    enumeration 
        WASH_NO_REQ (0);
        WASH_LO (1);
    end
end

