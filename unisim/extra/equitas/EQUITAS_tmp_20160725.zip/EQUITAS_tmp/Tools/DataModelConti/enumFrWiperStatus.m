classdef enumFrWiperStatus < Simulink.IntEnumType
    enumeration 
        STATUS_NOT_ACTIVE (0);
        STATUS_LOW_SPEED (1);
        STATUS_HIGH_SPEED (2);
        STATUS_INVALID (3);
    end
end
