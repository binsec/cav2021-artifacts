classdef enumFrWiperTrigger < Simulink.IntEnumType
    enumeration 
        TRIG_STOP (0);
        TRIG_SW_LO_HI (1);
        TRIG_WASHER (2);
        TRIG_INT (3);
        TRIG_RAIN_LO (4);
        TRIG_RAIN_HI (5);
    end
end

