classdef enumLightSW < Simulink.IntEnumType
    enumeration
        LSW_OFF (0);
        LSW_AUTO (1);
        LSW_LOW (2);
        LSW_HIGH (3)
    end
end

