classdef enumWiperAL_Req < Simulink.IntEnumType
    enumeration
        LIGHT_OFF (0);
        LIGHT_LO (1);
    end
end

