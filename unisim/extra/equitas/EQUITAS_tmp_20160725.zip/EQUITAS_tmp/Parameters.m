%% Disable Sherpa Main Control
CtrlSherpaSelected = false;


%% Conti configuration
parm_FR_RR_DRIP_WIP_CONFIG = 0;


%% Wait time for visu
WaitTimeForSimu = 0.01;

%% System Constants
R = 0.22;
L = 0.0025;
r = 1/44;
J = 0.000052+0.126*r^2;
J2 = 0.000052+0.091*r^2;
visc = 0.000092;
Ke = 0.0295;
Kc = 0.0295;
Kfriction = 14.4*0.8*0.67;
Kweight = -0.25*(0.5+0.176)*9.81*sin(23*pi/180);
Kaero = 0.0036;
T = 0.01;

%% Stateflow Manager
T_Period = 0.01; % s
Off = 0; % -
Standby = 10; % -
Intermitent = 1; % -
LowSpeedMode = 2; % -
HighSpeedMode = 3; % -

% Parameters definition
T_Wash = 3; % s
%Wiper_LS_Frequency = 40/60; % Hz
%Wiper_HS_Frequency = 60/60; % Hz

Wiper_LS_Frequency = 0.755; 
Wiper_HS_Frequency = 1.145; 

Wiper_Frequency_In = [0 60 120 200];  % km/h
Wiper_LS_Frequency_Out = [0.755 0.755 0.755 0.755]; % Hz
Wiper_HS_Frequency_Out = [1.145 1.145 1.145 1.145]; % Hz

Wipers_Intermitent_Time_Row = [0 60 120 200]; % km/h
Wipers_Intermitent_Time_Col = [1 2 3 4 5 6 7]; % -
Wipers_Intermitent_Time_Out = [... % s
    [1.5 1.4 1.3 1.2 1.1 1.0 0.9];...
    [1.4 1.3 1.2 1.1 1.0 0.9 0.8];...
    [1.3 1.2 1.1 1.0 0.9 0.8 0.7];...
    [1.2 1.1 1.0 0.9 0.8 0.7 0.6]];

Wipers_Intermitent_Time = 1; % s

%% Wipers Geometry
Passenger.Pivot         = [1300 0]/1000;
Passenger.Blade1        = [1300-210 65]/1000;
Passenger.Clip          = [1300-210-300 65]/1000;
Passenger.Blade2        = [1300-210-580 65]/1000;
Passenger.PressForce    = 13.5;
Passenger.InWipe        = atan2((Passenger.Blade2(:,2)-Passenger.Pivot(:,2)),(Passenger.Blade2(:,1)-Passenger.Pivot(:,1)))*180/pi;
Passenger.OutWipe       = 100.4;

Driver.Pivot            = [0 0]/1000;
Driver.Blade1           = [220 85]/1000;
Driver.Clip             = [220+293.5 123.5]/1000;
Driver.Blade2           = [220+560 156]/1000;
Driver.PressForce       = 14.4;
Driver.Inwipe           = atan2((Driver.Blade2(:,2)-Driver.Pivot(:,2)),(Driver.Blade2(:,1)-Driver.Pivot(:,1)))*180/pi;
Driver.OutWipe          = 86.7;

% D_ArmLength = 0.67;
% D_BladeLength = 0.8;
% D_PressForce = 14.4;
% P_ArmLength = 0.58;
% P_BladeLength = 0.75;
% P_PressForce = 13.5;

D_ArmLength = sqrt(sum((Driver.Clip-Driver.Pivot).^2));
D_BladeLength = sqrt(sum((Driver.Blade2-Driver.Blade1).^2));
D_PressForce = Driver.PressForce;
P_ArmLength = sqrt(sum((Passenger.Clip-Passenger.Pivot).^2));
P_BladeLength = sqrt(sum((Passenger.Blade2-Passenger.Blade1).^2));
P_PressForce = Passenger.PressForce;


%% Passenger & Driver wipers parameters
% Initial value for passenger wiper
IV_Angle_P_C_Pass = atan((Passenger.Clip(2)-Passenger.Pivot(2)) / (Passenger.Clip(1)-Passenger.Pivot(1)));
IV_Angle_P_B1_Pass = atan((Passenger.Blade1(2)-Passenger.Pivot(2)) / (Passenger.Blade1(1)-Passenger.Pivot(1)));
IV_Angle_P_B2_Pass = atan((Passenger.Blade2(2)-Passenger.Pivot(2)) / (Passenger.Blade2(1)-Passenger.Pivot(1)));

% Gain for passenger
Pos_Clip_Pass = sqrt((Passenger.Clip(1)-Passenger.Pivot(1))^2 +  (Passenger.Clip(2)-Passenger.Pivot(2))^2);
Pos_Blade1_Pass = sqrt((Passenger.Blade1(1)-Passenger.Pivot(1))^2 +  (Passenger.Blade1(2)-Passenger.Pivot(2))^2);
Pos_Blade2_Pass = sqrt((Passenger.Blade2(1)-Passenger.Pivot(1))^2 +  (Passenger.Blade2(2)-Passenger.Pivot(2))^2);

% Initial value for driver wiper
IV_Angle_P_C_Driv = atan((Driver.Clip(2)-Driver.Pivot(2)) / (-Driver.Clip(1)+Driver.Pivot(1)));
IV_Angle_P_B2_Driv = atan((Driver.Blade2(2)-Driver.Pivot(2)) / (-Driver.Blade2(1)+Driver.Pivot(1)));
IV_Angle_P_B1_Driv = atan((Driver.Blade1(2)-Driver.Pivot(2)) / (-Driver.Blade1(1)+Driver.Pivot(1)));

% Gain for driver
Pos_Clip_Driv = sqrt((Driver.Clip(1)-Driver.Pivot(1))^2 +  (Driver.Clip(2)-Driver.Pivot(2))^2);
Pos_Blade2_Driv = sqrt((Driver.Blade2(1)-Driver.Pivot(1))^2 +  (Driver.Blade2(2)-Driver.Pivot(2))^2);
Pos_Blade1_Driv = sqrt((Driver.Blade1(1)-Driver.Pivot(1))^2 +  (Driver.Blade1(2)-Driver.Pivot(2))^2);


%% Ideal Trajectories
IdealTrajectory_S=[0.000	0.032	0.048	0.064	0.080	0.096	0.112	0.129	0.145	0.162	0.179	0.196	0.214	0.232	0.250	0.270	0.289	0.310	0.331	0.353	0.375	0.399	0.423	0.449	0.475	0.502	0.531	0.561	0.591	0.624	0.657	0.692	0.728	0.766	0.805	0.845	0.887	0.930	0.974	1.000];
IdealTrajectory_Driver=	[3	7	9	11	13	15	17	19	21	23	25	27	29	31	33	35	37	39	41	43	45	47	49	51	53	55	57	59	61	63	65	67	69	71	73	75	77	79	81	82.3];
IdealTrajectory_Passenger=[0.3	0.3	0.3	0.3	0.5	0.8	1.2	1.7	2.3	2.975	3.689	4.517	5.461	6.525	7.714	9.030	10.477	12.059	13.780	15.642	17.650	19.808	22.118	24.584	27.211	30.001	32.958	36.087	39.389	42.870	46.532	50.380	54.416	58.743	63.237	67.897	72.722	77.712	82.866	85.800];


%% Trajectory Generation
% load fit1;
% poly0 = fit1.coeff*pi/180;
% poly1 = polyder(poly0);
% poly2 = polyder(poly1);
% poly3 = polyder(poly2);


% StateSpace_Control;

