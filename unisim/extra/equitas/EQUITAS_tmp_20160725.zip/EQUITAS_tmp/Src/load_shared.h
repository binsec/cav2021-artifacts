/*
 * load_shared.h
 *
 *  Created on: 6 nov. 2014
 *      Author: rnouacer
 */

#ifndef LOAD_SHARED_H_
#define LOAD_SHARED_H_

#include <stdbool.h>
//#include <inttypes.h>
#include <stdint.h>

#include <can_struct.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum API_FUNC_ID {API_CREATE_OBJECT, API_COMPUTE, API_DELETE_OBJECT } API_FUNC_ID;

bool api_load_test_case(const char* xml_testcase_full_path);

int api_call_func(const char* lib_name, API_FUNC_ID fid, int argc, const char **argv);

bool api_unload_test_case();

double api_setATD0(double anValue8[8]);
double api_setATD1(double anValue16[16]);
double api_getPWM(bool (*pwmValue)[8]);
double api_setCAN(CAN_DATATYPE msg);
double api_getCAN(CAN_DATATYPE *msg);
double api_setCANArray(CAN_DATATYPE_ARRAY msg);
double api_getCANArray(CAN_DATATYPE_ARRAY *msg);

double api_symWrite8(const char* strName, uint8_t val);
double api_symRead8(const char* strName, uint8_t* val);
double api_symWrite16(const char* strName, uint16_t val);
double api_symRead16(const char* strName, uint16_t* val);

#ifdef __cplusplus
}
#endif

#endif /* LOAD_SHARED_H_ */
