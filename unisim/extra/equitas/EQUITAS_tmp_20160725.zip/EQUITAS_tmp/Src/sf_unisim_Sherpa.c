/************************** S-Function ***********************
 * File :
 *
 * Description :
 *
 * Input(s) :
 *
 *
 * Output(s) :
 *
 *
 * List of  parameter(s) :
 *
 *
 *
 * Example :
 *
 *
 * Versions :
 *   1.0 -- 15/07/15 -- Y.FREMY (Sherpa Engineering) -- Creation
 *
 * Copyright (c) 2014 Sherpa Engineering
 **************************************************************************/


#define EDIT_OK(S, ARG) \
(!((ssGetSimMode(S) == SS_SIMMODE_SIZES_CALL_ONLY) && mxIsEmpty(ARG)))

#define S_FUNCTION_NAME  sf_unisim_Sherpa
#define S_FUNCTION_LEVEL 2
#define ShowMessage false  // false not display, true display message
#define STR_MAX_LENGTH 1024
#define IS_PARAM_NUMERIC(pVal) (mxIsNumeric(pVal) && !mxIsLogical(pVal) &&\
!mxIsEmpty(pVal) && !mxIsSparse(pVal) && !mxIsComplex(pVal))

//#define WIN32 // YF Only for Sherpa computer

/****************************
 * Add the required library *
 ****************************/
#include "simstruc.h"
#include "mex.h"

#include "load_shared.h"

/****************************
 * Define Enum data         *
 ****************************/
// Defines Enums for parameters management
enum {
    Enum_full_sh_path = 0,
    Enum_NUM_PARAMS,
};

// Defines Enums for inports management
enum {
    Enum_IGNMode = 0,
    Enum_Supply_Tension,
    Enum_Wiper_mode,
    Enum_Winshield_washer,
    Enum_Wiper_INT_volume,
    Enum_Vehicle_Speed,
    nInputPorts
};
// Defines Enums for outports management
enum {
	Enum_WiperOut = 0,
    Enum_WasherOut,
    nOutputPorts
};


/* Function: mdlCheckParameters ******************************************
 * Abstract:
 *  mdlCheckParameters verifies new parameter settings whenever parameter
 * change or are re-evaluated during a simulation. When a simulation is
 * running, changes to S-function parameters can occur at any time during
 * the simulation loop.
 */

#define MDL_CHECK_PARAMETERS   /* Change to #undef to remove function */
#if defined(MDL_CHECK_PARAMETERS) && defined(MATLAB_MEX_FILE)

static void mdlCheckParameters(SimStruct *S)
{
    // Define variables
    const mxArray *PARAM;
    char_T full_sh_path[STR_MAX_LENGTH];
    int GetStrErr;

# if ShowMessage
    mexPrintf(" --- mdlCheckParameters 1st & 2nd ---\n");
#endif
    
    // Get the path for the Test case
    GetStrErr = mxGetString(ssGetSFcnParam(S, Enum_full_sh_path), full_sh_path, STR_MAX_LENGTH);
    if (GetStrErr) {
        ssSetErrorStatus(S,"Test case path is too long and had been truncated!");
        return;
    }
    PARAM = ssGetSFcnParam(S,Enum_full_sh_path);
    
# if ShowMessage
    mexPrintf("   --> mdlCheckParameters : Test case path = %s \n", full_sh_path);
#endif
    
    // Check the parameter full_sh_path
    if (!mxIsChar(PARAM)) { // IsChar
        ssSetErrorStatus(S,"full_sh_path parameter to S-function must be a string of characters!");
        return;
    }
    if( strlen(full_sh_path) == 0) { // Is empty
        ssSetErrorStatus(S,"full_sh_path parameter to S-function is empty!");
        return;
    }
    
# if ShowMessage
    mexPrintf("\n");
#endif
}
#endif /* MDL_CHECK_PARAMETERS */


/* Function: mdlInitializeSizes ******************************************
 * - Abstract:
 *    The sizes information is used by Simulink to determine the S-function
 *    block's characteristics (number of inputs, outputs, states, etc.).
 * - STIE :
 */

static void mdlInitializeSizes(SimStruct *S)
{
    
    
    // ********************************************************************
    // Variable Local
    // Variables for new datatype
    int_T				status;
    
    # if ShowMessage
        mexPrintf("\n$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
        mexPrintf("$                           mdlInitializeSizes                              $\n");
        mexPrintf("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
        mexPrintf("$ Number of parametres : %d                                                  $\n",ssGetSFcnParamsCount(S));
    #endif


    // ********************************************************************
    // Parameters
    // Number of expected parameters //
    if(ssGetSFcnParamsCount(S) == Enum_NUM_PARAMS)
    {
        mdlCheckParameters(S);
        ssSetNumSFcnParams(S, Enum_NUM_PARAMS);  /* Number of expected parameters */
    }
    else
    {
        return; /* The Simulink engine reports a mismatch error. */
    }


    // ********************************************************************
    // Defines ports
    
    # if ShowMessage
        mexPrintf(" Id_CAN_DATATYPE_ARRAY = %d \n",Id_CAN_DATATYPE_ARRAY);
    #endif

    // Add inports
    if (!ssSetNumInputPorts(S, nInputPorts)) return;
    // IGNMode input
    ssSetInputPortWidth(             S, Enum_IGNMode, 1 );
    ssSetInputPortDataType(          S, Enum_IGNMode, SS_UINT8);
    ssSetInputPortDirectFeedThrough( S, Enum_IGNMode, 1);
    ssSetInputPortRequiredContiguous(S, Enum_IGNMode, 1);
    // Supply_Tension input
    ssSetInputPortWidth(             S, Enum_Supply_Tension, 1 );
    ssSetInputPortDataType(          S, Enum_Supply_Tension, SS_UINT8);
    ssSetInputPortDirectFeedThrough( S, Enum_Supply_Tension, 1);
    ssSetInputPortRequiredContiguous(S, Enum_Supply_Tension, 1);
    // Wiper_mode input
    ssSetInputPortWidth(             S, Enum_Wiper_mode, 1 );
    ssSetInputPortDataType(          S, Enum_Wiper_mode, SS_UINT8);
    ssSetInputPortDirectFeedThrough( S, Enum_Wiper_mode, 1);
    ssSetInputPortRequiredContiguous(S, Enum_Wiper_mode, 1);
    // Winshield_washer input
    ssSetInputPortWidth(             S, Enum_Winshield_washer, 1 );
    ssSetInputPortDataType(          S, Enum_Winshield_washer, SS_BOOLEAN);
    ssSetInputPortDirectFeedThrough( S, Enum_Winshield_washer, 1);
    ssSetInputPortRequiredContiguous(S, Enum_Winshield_washer, 1);
    // Wiper_INT_volume input
    ssSetInputPortWidth(             S, Enum_Wiper_INT_volume, 1 );
    ssSetInputPortDataType(          S, Enum_Wiper_INT_volume, SS_UINT8);
    ssSetInputPortDirectFeedThrough( S, Enum_Wiper_INT_volume, 1);
    ssSetInputPortRequiredContiguous(S, Enum_Wiper_INT_volume, 1);
    // Vehicle_Speed input
    ssSetInputPortWidth(             S, Enum_Vehicle_Speed, 1 );
    ssSetInputPortDataType(          S, Enum_Vehicle_Speed, SS_UINT8);
    ssSetInputPortDirectFeedThrough( S, Enum_Vehicle_Speed, 1);
    ssSetInputPortRequiredContiguous(S, Enum_Vehicle_Speed, 1);
    
    
    // Add outports
    if (!ssSetNumOutputPorts(S, nOutputPorts)) return;
    // WiperOut output
    ssSetOutputPortWidth(	S, Enum_WiperOut, 1 );
    ssSetOutputPortDataType(S, Enum_WiperOut, SS_UINT8);
    // WasherOut output
    ssSetOutputPortWidth(	S, Enum_WasherOut, 1 );
    ssSetOutputPortDataType(S, Enum_WasherOut, SS_BOOLEAN);

    // ********************************************************************
    // Define others parameters for S-function
    ssSetNumRWork(         S, 0);   // number of real work vector elements
    ssSetNumIWork(         S, 0);   // number of integer work vector elements
    ssSetNumPWork(         S, 0);   // number of pointer work vector elements
    ssSetNumModes(         S, 0);   // number of mode work vector elements
    ssSetNumNonsampledZCs( S, 0);   // number of nonsampled zero crossings
    // Register the number and type of states the S-Function uses
    ssSetNumContStates(    S, 0);   // number of continuous states
    ssSetNumDiscStates(    S, 0);   // number of discrete states
    ssSetNumSampleTimes(   S, 0);   // number of sample times
    // Specify the sim state compliance to be same as a built-in block
    ssSetSimStateCompliance(S, USE_DEFAULT_SIM_STATE);
    // general options (SS_OPTION_xx)
    ssSetOptions(          S, 0);

    # if ShowMessage
        mexPrintf("\n$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
        mexPrintf("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n\n");
    #endif
} /* end mdlInitializeSizes */


/* Function: mdlInitializeSampleTimes *************************************
 * Abstract:
 *
 * This function is used to specify the sample time(s) for your S-function.
 * You must register the same number of sample times as specified in
 * ssSetNumSampleTimes. If you specify that you have no sample times, then
 * the S-function is assumed to have one inherited sample time.
 */
static void mdlInitializeSampleTimes(SimStruct *S)
{
    
    #if ShowMessage
        mexPrintf("\n$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
        mexPrintf("$                         mdlInitializeSampleTimes                          $\n");
        mexPrintf("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
        // mexPrintf("  --> Sample time  = %f\n",mxGetPr(ts)[0]);
    #endif

    ssSetSampleTime(S, 0, INHERITED_SAMPLE_TIME);
    ssSetOffsetTime(S, 0, FIXED_IN_MINOR_STEP_OFFSET);

    # if ShowMessage
        mexPrintf("\n$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
        mexPrintf("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n\n");
    #endif
} /* end mdlInitializeSampleTimes */


/* Function: mdlStart ****************************************************
 * Abstract:
 *    This function is called once at start of model execution. If you
 *    have states that should be initialized once, this is the place
 *    to do it.
 *
 */
#define MDL_START  /* Change to #undef to remove function */
#if defined(MDL_START)

static void mdlStart(SimStruct *S)
{
    
    // Define variables //
    char full_sh_path[STR_MAX_LENGTH];
    
    # if ShowMessage
        mexPrintf("\n$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
        mexPrintf("$                           mdlStart                                        $\n");
        mexPrintf("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
        mexPrintf("$ Number of parametres : %d                                                  $\n",ssGetSFcnParamsCount(S));
    #endif
    
    // Get the path for the Test case
    mxGetString(ssGetSFcnParam(S, Enum_full_sh_path), full_sh_path, STR_MAX_LENGTH);
    
    // code under development
    
    api_load_test_case(full_sh_path);
    
    
    #if ShowMessage
    mexPrintf("\n$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
    mexPrintf("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n\n");
    #endif
}
#endif /*  MDL_START */


/* Function: mdlOutputs *******************************************************
 * Abstract:
 *    In this function, you compute the outputs of your S-function
 *    block. Generally outputs are placed in the output vector(s),
 *    ssGetOutputPortSignal.
 */
static void mdlOutputs(SimStruct *S, int_T tid)
{
    
    // Define variables
    const char* ar[1] = {"10"};
    char buff[80];
    
    time_T t = ssGetSampleTime(S, 0);
    
    // Manages inputs
    const uint8_T* IGNMode   = ssGetInputPortSignal(S,Enum_IGNMode);
    const uint8_T* Supply_Tension   = ssGetInputPortSignal(S,Enum_Supply_Tension);
    const uint8_T* Wiper_mode   = ssGetInputPortSignal(S,Enum_Wiper_mode);
    const bool* Winshield_washer   = ssGetInputPortSignal(S,Enum_Winshield_washer);
    const uint8_T* Wiper_INT_volume   = ssGetInputPortSignal(S,Enum_Wiper_INT_volume);
    const uint8_T* Vehicle_Speed   = ssGetInputPortSignal(S,Enum_Vehicle_Speed);
    
    // Manages outputs
    const uint8_T* WiperOut  = ssGetOutputPortSignal(S,Enum_WiperOut);    
    const bool* WasherOut  = ssGetOutputPortSignal(S,Enum_WasherOut);    
    
    #if ShowMessage
        mexPrintf("\n$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
        mexPrintf("$                                mdlOutputs                                 $\n");
        mexPrintf("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
    #endif
    
    /* NOUEVLLE API
     */
    
    api_symWrite8("IGNMode", *IGNMode);
    api_symWrite8("Supply_Tension", *Supply_Tension);
    api_symWrite8("Wiper_mode", *Wiper_mode);
    api_symWrite8("Winshield_washer", *Winshield_washer);
    api_symWrite8("Wiper_INT_volume", *Wiper_INT_volume);
    api_symWrite8("Vehicle_Speed", *Vehicle_Speed);
    
//    double api_symRead16(const char* strName, uint16_t* val);
    
    sprintf(buff,"%f",t*1000);
    ar[0] = buff;
    
    api_call_func("unisim", API_COMPUTE, 1, ar);
    
    api_symRead8("WiperOut", WiperOut);
    api_symRead8("WasherOut", WasherOut);
    
     /*
     */
    
    #if ShowMessage
        mexPrintf("\n$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
        mexPrintf("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n\n");
    #endif

} /* end mdlOutputs */



/* Function: mdlTerminate *****************************************************
 * Abstract:
 *    In this function, you should perform any actions that are necessary
 *    at the termination of a simulation.  For example, if memory was allocated
 *    in mdlStart, this is the place to free it.
 */
static void mdlTerminate(SimStruct *S)
{
    
    #if ShowMessage
        mexPrintf("\n$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
        mexPrintf("$                               mdlTerminate                                $\n");
        mexPrintf("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
    #endif

    api_unload_test_case();
    
    
    # if ShowMessage
        mexPrintf("\n$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
        mexPrintf("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n\n");
    #endif
}




/*******************************
 * Required S-function trailer *
 *******************************/

#ifdef  MATLAB_MEX_FILE    /* Is this file being compiled as a MEX-file? */
#include "simulink.c"      /* MEX-file interface mechanism */
#else
#include "cg_sfun.h"       /* Code generation registration function */
#endif
