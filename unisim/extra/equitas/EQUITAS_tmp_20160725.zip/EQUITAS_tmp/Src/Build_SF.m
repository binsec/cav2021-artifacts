% ======================== Build_SF =============================
%
% This script will compile the s-function.
%
%
% Versions :
% 1.0 -- 21/06/16 -- Y. FREMY (Sherpa Engineering) -- Creation
%

function Build_SF(varargin)
clc;

mex -v COMPFLAGS="-g -c -ISrc -DMATLAB_MEX_FILE" LINKFLAGS="-LC:\Users\Yann\AppData\Roaming\MathWorks\MATLAB\R2012b\gnumex" sf_unisim.c Tools\unisim-vp\libunisim-loader.dll.a

end