/************************** S-Function ***********************
 * File :
 *
 * Description :
 *
 * Input(s) :
 *
 *
 * Output(s) :
 *
 *
 * List of  parameter(s) :
 *
 *
 *
 * Example :
 *
 *
 * Versions :
 *   1.0 -- 15/07/15 -- Y.FREMY (Sherpa Engineering) -- Creation
 *
 * Copyright (c) 2014 Sherpa Engineering
 **************************************************************************/


#define EDIT_OK(S, ARG) \
(!((ssGetSimMode(S) == SS_SIMMODE_SIZES_CALL_ONLY) && mxIsEmpty(ARG)))

#define S_FUNCTION_NAME  sf_unisim
#define S_FUNCTION_LEVEL 2
#define ShowMessage false  // false not display, true display message
#define STR_MAX_LENGTH 1024
#define IS_PARAM_NUMERIC(pVal) (mxIsNumeric(pVal) && !mxIsLogical(pVal) &&\
!mxIsEmpty(pVal) && !mxIsSparse(pVal) && !mxIsComplex(pVal))

//#define WIN32 // YF Only for Sherpa computer

/****************************
 * Add the required library *
 ****************************/
#include "simstruc.h"
#include "mex.h"

#include "load_shared.h"
#include "can_struct.h"


/****************************
 * Define Enum data         *
 ****************************/
// Defines Enums for parameters management
enum {
    Enum_full_sh_path = 0,
    Enum_NUM_PARAMS,
};

// Defines Enums for inports management
enum {
    Enum_Wiper_mode = 0,
    Enum_Wiper_INT_volume,
    Enum_Winshield_washer,
    Enum_Supply_Voltage,
    Enum_CAN1_In,
    nInputPorts
};
// Defines Enums for outports management
enum {
	Enum_CAN1_Out = 0,
    nOutputPorts
};


/* Function: mdlCheckParameters ******************************************
 * Abstract:
 *  mdlCheckParameters verifies new parameter settings whenever parameter
 * change or are re-evaluated during a simulation. When a simulation is
 * running, changes to S-function parameters can occur at any time during
 * the simulation loop.
 */

#define MDL_CHECK_PARAMETERS   /* Change to #undef to remove function */
#if defined(MDL_CHECK_PARAMETERS) && defined(MATLAB_MEX_FILE)

static void mdlCheckParameters(SimStruct *S)
{
    // Define variables
    const mxArray *PARAM;
    char_T full_sh_path[STR_MAX_LENGTH];
    int GetStrErr;

# if ShowMessage
    mexPrintf(" --- mdlCheckParameters 1st & 2nd ---\n");
#endif
    
    // Get the path for the Test case
    GetStrErr = mxGetString(ssGetSFcnParam(S, Enum_full_sh_path), full_sh_path, STR_MAX_LENGTH);
    if (GetStrErr) {
        ssSetErrorStatus(S,"Test case path is too long and had been truncated!");
        return;
    }
    PARAM = ssGetSFcnParam(S,Enum_full_sh_path);
    
# if ShowMessage
    mexPrintf("   --> mdlCheckParameters : Test case path = %s \n", full_sh_path);
#endif
    
    // Check the parameter full_sh_path
    if (!mxIsChar(PARAM)) { // IsChar
        ssSetErrorStatus(S,"full_sh_path parameter to S-function must be a string of characters!");
        return;
    }
    if( strlen(full_sh_path) == 0) { // Is empty
        ssSetErrorStatus(S,"full_sh_path parameter to S-function is empty!");
        return;
    }
    
# if ShowMessage
    mexPrintf("\n");
#endif
}
#endif /* MDL_CHECK_PARAMETERS */


/* Function: mdlInitializeSizes ******************************************
 * - Abstract:
 *    The sizes information is used by Simulink to determine the S-function
 *    block's characteristics (number of inputs, outputs, states, etc.).
 * - STIE :
 */

static void mdlInitializeSizes(SimStruct *S)
{
    
    
    // ********************************************************************
    // Variable Local
    // Variables for new datatype
    int_T				status;
    DTypeId				Id_CAN_DATATYPE_ARRAY;
    CAN_DATATYPE_ARRAY	CAN_Msg;
    
    # if ShowMessage
        mexPrintf("\n$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
        mexPrintf("$                           mdlInitializeSizes                              $\n");
        mexPrintf("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
        mexPrintf("$ Number of parametres : %d                                                  $\n",ssGetSFcnParamsCount(S));
    #endif


    // ********************************************************************
    // Parameters
    // Number of expected parameters //
    if(ssGetSFcnParamsCount(S) == Enum_NUM_PARAMS)
    {
        mdlCheckParameters(S);
        ssSetNumSFcnParams(S, Enum_NUM_PARAMS);  /* Number of expected parameters */
    }
    else
    {
        return; /* The Simulink engine reports a mismatch error. */
    }


    // ********************************************************************
    // Defines ports
    // Add datatype for CAN message array
    Id_CAN_DATATYPE_ARRAY = ssRegisterDataType(S,"CAN_DATATYPE_ARRAY");
    if(Id_CAN_DATATYPE_ARRAY == INVALID_DTYPE_ID)
    {
        ssSetErrorStatus(S,"Impossible to add the datatype for the CAN message array");
        return;
    }
    // Set the size
    status = ssSetDataTypeSize(S, Id_CAN_DATATYPE_ARRAY, sizeof(CAN_DATATYPE_ARRAY));
    if(status == 0)
    {
        ssSetErrorStatus(S,"Impossible to set the size for the CAN message array");
        return;
    }
    // Set the zero representation
    CAN_Msg.nmsgs = 0;
    CAN_Msg.canMsg = NULL;
    status = ssSetDataTypeZero(S, Id_CAN_DATATYPE_ARRAY, &CAN_Msg);
    if(status == 0)
    {
        ssSetErrorStatus(S,"Impossible to set the zero for the CAN message array");
        return;
    }

    # if ShowMessage
        mexPrintf(" Id_CAN_DATATYPE_ARRAY = %d \n",Id_CAN_DATATYPE_ARRAY);
    #endif

    // Add inports
    if (!ssSetNumInputPorts(S, nInputPorts)) return;
    // CAN1 input
    ssSetInputPortWidth(             S, Enum_CAN1_In, 1 );
    ssSetInputPortDataType(          S, Enum_CAN1_In, Id_CAN_DATATYPE_ARRAY);
    ssSetInputPortDirectFeedThrough( S, Enum_CAN1_In, 1);
    ssSetInputPortRequiredContiguous(S, Enum_CAN1_In, 1);
    // Wiper Mode bits
    ssSetInputPortWidth(             S, Enum_Wiper_mode, 3 );
    ssSetInputPortDataType(          S, Enum_Wiper_mode, SS_BOOLEAN);
    ssSetInputPortDirectFeedThrough( S, Enum_Wiper_mode, 1);
    ssSetInputPortRequiredContiguous(S, Enum_Wiper_mode, 1);
    // Wiper INT volume bits
    ssSetInputPortWidth(             S, Enum_Wiper_INT_volume, 3 );
    ssSetInputPortDataType(          S, Enum_Wiper_INT_volume, SS_BOOLEAN);
    ssSetInputPortDirectFeedThrough( S, Enum_Wiper_INT_volume, 1);
    ssSetInputPortRequiredContiguous(S, Enum_Wiper_INT_volume, 1);
    // Windshield washer
    ssSetInputPortWidth(             S, Enum_Winshield_washer, 1 );
    ssSetInputPortDataType(          S, Enum_Winshield_washer, SS_BOOLEAN);
    ssSetInputPortDirectFeedThrough( S, Enum_Winshield_washer, 1);
    ssSetInputPortRequiredContiguous(S, Enum_Winshield_washer, 1);
    // Supply voltage
    ssSetInputPortWidth(             S, Enum_Supply_Voltage, 1 );
    ssSetInputPortDataType(          S, Enum_Supply_Voltage, SS_DOUBLE);
    ssSetInputPortDirectFeedThrough( S, Enum_Supply_Voltage, 1);
    ssSetInputPortRequiredContiguous(S, Enum_Supply_Voltage, 1);
    
    
    // Add outports
    if (!ssSetNumOutputPorts(S, nOutputPorts)) return;
    // CAN1 output
    ssSetOutputPortWidth(	S, Enum_CAN1_Out, 1 );
    ssSetOutputPortDataType(S, Enum_CAN1_Out, Id_CAN_DATATYPE_ARRAY);


    // ********************************************************************
    // Define others parameters for S-function
    ssSetNumRWork(         S, 0);   // number of real work vector elements
    ssSetNumIWork(         S, 0);   // number of integer work vector elements
    ssSetNumPWork(         S, 0);   // number of pointer work vector elements
    ssSetNumModes(         S, 0);   // number of mode work vector elements
    ssSetNumNonsampledZCs( S, 0);   // number of nonsampled zero crossings
    // Register the number and type of states the S-Function uses
    ssSetNumContStates(    S, 0);   // number of continuous states
    ssSetNumDiscStates(    S, 0);   // number of discrete states
    ssSetNumSampleTimes(   S, 0);   // number of sample times
    // Specify the sim state compliance to be same as a built-in block
    ssSetSimStateCompliance(S, USE_DEFAULT_SIM_STATE);
    // general options (SS_OPTION_xx)
    ssSetOptions(          S, 0);

    # if ShowMessage
        mexPrintf("\n$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
        mexPrintf("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n\n");
    #endif
} /* end mdlInitializeSizes */


/* Function: mdlInitializeSampleTimes *************************************
 * Abstract:
 *
 * This function is used to specify the sample time(s) for your S-function.
 * You must register the same number of sample times as specified in
 * ssSetNumSampleTimes. If you specify that you have no sample times, then
 * the S-function is assumed to have one inherited sample time.
 */
static void mdlInitializeSampleTimes(SimStruct *S)
{
    
    #if ShowMessage
        mexPrintf("\n$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
        mexPrintf("$                         mdlInitializeSampleTimes                          $\n");
        mexPrintf("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
        // mexPrintf("  --> Sample time  = %f\n",mxGetPr(ts)[0]);
    #endif

    ssSetSampleTime(S, 0, INHERITED_SAMPLE_TIME);
    ssSetOffsetTime(S, 0, FIXED_IN_MINOR_STEP_OFFSET);

    # if ShowMessage
        mexPrintf("\n$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
        mexPrintf("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n\n");
    #endif
} /* end mdlInitializeSampleTimes */


/* Function: mdlStart ****************************************************
 * Abstract:
 *    This function is called once at start of model execution. If you
 *    have states that should be initialized once, this is the place
 *    to do it.
 *
 */
#define MDL_START  /* Change to #undef to remove function */
#if defined(MDL_START)

static void mdlStart(SimStruct *S)
{
    
    // Define variables //
    char full_sh_path[STR_MAX_LENGTH];
    
    # if ShowMessage
        mexPrintf("\n$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
        mexPrintf("$                           mdlStart                                        $\n");
        mexPrintf("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
        mexPrintf("$ Number of parametres : %d                                                  $\n",ssGetSFcnParamsCount(S));
    #endif

    // code under development
    
    
    // Get the path for the Test case
    mxGetString(ssGetSFcnParam(S, Enum_full_sh_path), full_sh_path, STR_MAX_LENGTH);
    
    api_load_test_case(full_sh_path);

    #if ShowMessage
    mexPrintf("\n$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
    mexPrintf("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n\n");
    #endif
}
#endif /*  MDL_START */


/* Function: mdlOutputs *******************************************************
 * Abstract:
 *    In this function, you compute the outputs of your S-function
 *    block. Generally outputs are placed in the output vector(s),
 *    ssGetOutputPortSignal.
 */
static void mdlOutputs(SimStruct *S, int_T tid)
{
    
    // Define variables
    const char* ar[1] = {"10"};
    char buff[80];
    
    time_T t = ssGetSampleTime(S, 0);
    
    // Manages inputs
    const bool* Wiper_mode   = ssGetInputPortSignal(S,Enum_Wiper_mode);
    const bool* Wiper_INT_volume   = ssGetInputPortSignal(S,Enum_Wiper_INT_volume);
    const bool* Winshield_washer   = ssGetInputPortSignal(S,Enum_Winshield_washer);
    const double* Supply_Voltage   = ssGetInputPortSignal(S,Enum_Supply_Voltage);
    
    // Manages inputs & outputs for CAN1
    const CAN_DATATYPE_ARRAY* CAN1_Msg_In   = ssGetInputPortSignal(S,Enum_CAN1_In);
    const CAN_DATATYPE_ARRAY* CAN1_Msg_Out  = ssGetOutputPortSignal(S,Enum_CAN1_Out);    
    
    #if ShowMessage
    mexPrintf("\n$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
    mexPrintf("$                                mdlOutputs                                 $\n");
    mexPrintf("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
    #endif

/* this line is generated by Matlab/legacy_code
 * api_unisim( *CAN1_Msg_In, *__y1BUS);
 */

    api_setCANArray(*CAN1_Msg_In);

    sprintf(buff,"%f",t*1000);
    ar[0] = buff;
    
    api_call_func("unisim", API_COMPUTE, 1, ar);

    api_getCANArray(CAN1_Msg_Out);

    #if ShowMessage
        mexPrintf("\n$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
        mexPrintf("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n\n");
    #endif

} /* end mdlOutputs */



/* Function: mdlTerminate *****************************************************
 * Abstract:
 *    In this function, you should perform any actions that are necessary
 *    at the termination of a simulation.  For example, if memory was allocated
 *    in mdlStart, this is the place to free it.
 */
static void mdlTerminate(SimStruct *S)
{
    
    #if ShowMessage
        mexPrintf("\n$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
        mexPrintf("$                               mdlTerminate                                $\n");
        mexPrintf("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
    #endif

    api_unload_test_case();

    # if ShowMessage
        mexPrintf("\n$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
        mexPrintf("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n\n");
    #endif
}




/*******************************
 * Required S-function trailer *
 *******************************/

#ifdef  MATLAB_MEX_FILE    /* Is this file being compiled as a MEX-file? */
#include "simulink.c"      /* MEX-file interface mechanism */
#else
#include "cg_sfun.h"       /* Code generation registration function */
#endif
