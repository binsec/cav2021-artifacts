%% File to setup the model EQUITAS

%% Select the model to use
MdlUseUnisim = 3; %% 0 => Conti , 1 => unisim , 2 => Sherpa , 3 => unisim avec le contr�le Sherpa
unisim = Simulink.Variant('MdlUseUnisim == 1');
conti = Simulink.Variant('MdlUseUnisim == 0');
sherpa = Simulink.Variant('MdlUseUnisim == 2');
unisim_sherpa = Simulink.Variant('MdlUseUnisim == 3');


%% Load a scenario
try
    Sce = ConvSce_EQUITAS(fullfile(pwd,'Cas_de_test_finis','Test_Case_00001.csv'));
catch
    %% Empty Scenario
    Sce = Scenario_Element();
end


%% Options setup
% Enable or disable fault management
EnableFault = false;


%% Constant definition for the model
% Conversion for the "Supply_Voltage" data
MDL_VoltageConv = 5/18;
MDL_VoltageReso = 1/(2^10);

% Conversion for "Wiper_mode" data
MDL_Intermittent = 1;
MDL_LowSpeed = 2;
MDL_HighSpeed = 3;

% Conversion for IGNMode
MDL_IGN_OFF = 0;
MDL_IGN_IGN = 3;
MDL_IGN_RUN = 4;


%% Enum from Continental
% Assign value for enumFrWiperStatus
enumFrWiperStatus_STATUS_NOT_ACTIVE = (0);
enumFrWiperStatus_STATUS_LOW_SPEED = (1);
enumFrWiperStatus_STATUS_HIGH_SPEED = (2);
enumFrWiperStatus_STATUS_INVALID = (3);

% Assign value for enumFrWiperPosition
enumFrWiperPosition_NOT_STOP = (0);
enumFrWiperPosition_STOP = (1);

% Assign value for enumFrWiperOut
enumFrWiperOut_OUT_STOP = (0);
enumFrWiperOut_OUT_FORCED_TO_STOP = (1);
enumFrWiperOut_OUT_ONE_LOW_SPEED = (2);
enumFrWiperOut_OUT_LOW_SPEED = (3);
enumFrWiperOut_OUT_HIGH_SPEED = (4);
enumFrWiperOut_OUT_ERROR = (5);


%% Setup Plant model
% Frequencies
Wiper_LS_Frequency = 0.7550;
Wiper_HS_Frequency = 1.1450;

% Intermittent constantes
Wipers_Intermitent_Time = 1;
Intermitent_Mode = 0;


%% Load the parameter for Model plant
Parameters;


%% Define CAN message
% Define constants
Intel = 0;
Motorola = 1;

% Frame length in bytes
DataBytes = 8;

% Define CAN frame
CAN1_Frame_In = [652,1573];
CAN1_Period_In = 0.02;
CAN1_Frame_Out = [861];
CAN1_Period_Out = 0.1;

% Define data from USM
SignalDef_1573 = [... %[StartBit   Length(in bits) Resolution  Offset  ByteOrder(0:Intel/1:Motorola)]
    4     2      1    0   Motorola;... % FrontWiperStatus
    6     1      1    0   Motorola;... % FrontWiperPosition
    28     1      1    0   Motorola;... % USM_IGN
    ];

% Define data from AT&CVT
SignalDef_652 = [... %[StartBit   Length(in bits) Resolution  Offset  ByteOrder(0:Intel/1:Motorola)]
    17     16      0.01    0   Motorola... % VEHICLE_SPEED_TCU
    ];

% Define data from BCM
SignalDef_861 = [... %[StartBit   Length(in bits) Resolution  Offset  ByteOrder(0:Intel/1:Motorola)]
    20     3      1    0   Motorola;... % FrWiperOut
    ];


%% Parameter for model EQUITAS_Sherpa
% Ignition values
ACC = 2;
IGN = 3;
RUN = 4;



