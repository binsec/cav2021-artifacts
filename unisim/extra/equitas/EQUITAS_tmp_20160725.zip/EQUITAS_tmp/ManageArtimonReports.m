function [Err] = ManageArtimonReports(ModelRef,ResultFile,TestData)
%% PostTreatmentType function type
% Do not modify the prototype (Inputs & outputs arguments) of this function 
% otherwise, it will not work properly with PhiTests
%
% Inputs:
%   ModelRef: Name of the model (Without extension mdl or slx) (char)
%   ResultFile: Name of the result file if any specified (char)
%   TestData: Structure which defines this test
%       Ref: Name of the test in progress (char)
%       Pre: Pre-scenario (char)
%       Sce: Scenario (char)
%       Post: Post-scenario (char)
%       Calib: Calibration file (m or mat file) (char)
%       PostTreatment: Function for post treatment to perform (char, field not mandatory)
%
% Outputs:
%   Err: Contains errors & warnings occurred during post treatment. Use the
%        Class Err_Class to be compatible with the Tester. If no error
%        management, initialize Err to empty data []
%

%% Init
% Output Err must return Err_Class or empty data
Err = Err_Class(); % To add an error, use "Set_Err" method


%% Develop your own post treatment function
% Take care, to get or set workspace data, you should use "evalin" or
% "assignin" functions (Cf. Matlab help)
%

% Get the model path
MdlPath = which(ModelRef,'-all');
if size(MdlPath,1) ~= 1
    if size(MdlPath,1) > 1
        error(['The model "',ModelRef,'" is shadowed in Matlab path']);
    else
        error(['The model "',ModelRef,'" was not found in Matlab path']);
    end
end
MdlPath = fileparts(MdlPath{1});

% Check if the Artimon report exist
ArtimonReportName = 'WiperSystem_Verdict.html';
ArtimonReport = fullfile(MdlPath,ArtimonReportName);

if exist(ArtimonReport) ~= 2
    % Report not found
    error(['The Artimon report was not found: "',ArtimonReport,'".']);
end

% Check if the result directory exist and create it if not
ResultDir = fullfile(MdlPath,'ArtimonReports');
if exist(ResultDir) ~= 7
    % Create the directory
    mkdir(ResultDir);
end

% Copy the report
movefile(ArtimonReport,ResultDir);

% rename the report
[ScePath,SceName] = fileparts(TestData.Ref);
movefile(fullfile(ResultDir,ArtimonReportName),fullfile(ResultDir,[SceName,'.html']));

end


